import json


def load(path):
    """Loads a JSON text file (e.g. modules/text/welcome.json)."""
    with open(path, "r") as f:
        return json.load(f)


def render(text, placeholders):
    """
    Replaces (key) tokens in a string with values from `placeholders`.

    e.g. render("Welcome (member) to (server name)",
                {"member": "@Bob", "server name": "FireBee HQ"})
    -> "Welcome @Bob to FireBee HQ"
    """
    if text is None:
        return text
    for key, value in placeholders.items():
        text = text.replace(f"({key})", str(value))
    return text


def render_all(section, placeholders):
    """Renders every string value in a dict, e.g. a whole {title, body, footer} block."""
    return {key: render(value, placeholders) for key, value in section.items()}
