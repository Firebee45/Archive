from datetime import datetime

RESET = "\033[0m"
CYAN = "\033[36m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"


def _stamp():
    return datetime.now().strftime("%H:%M:%S")


def info(source, message):
    print(f"{CYAN}[{_stamp()}] [{source}]{RESET} {message}")


def success(source, message):
    print(f"{GREEN}[{_stamp()}] [{source}] OK{RESET} - {message}")


def warn(source, message):
    print(f"{YELLOW}[{_stamp()}] [{source}] WARN{RESET} - {message}")


def error(source, message):
    print(f"{RED}[{_stamp()}] [{source}] ERROR{RESET} - {message}")
