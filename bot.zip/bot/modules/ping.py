import discord, time

META = {"name": "ping"}

def setup(bot):
    @bot.tree.command(name="ping", description="check bot latency")
    async def ping(interaction: discord.Interaction):
        start = time.perf_counter()
        await interaction.response.send_message("pong")
        ms = round((time.perf_counter() - start) * 1000)
        await interaction.edit_original_response(content=f"pong\n-# {ms}ms")