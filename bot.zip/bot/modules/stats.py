import discord
from discord import app_commands
from datetime import datetime, timezone
from collections import Counter
import re

import terminal_reports as log
import image_utils


META = {"name": "stats"}


# Finds normal URLs in message content
URL_REGEX = re.compile(
    r"https?://[^\s<>]+"
)

# Finds Discord custom emojis such as <:blob:123456789>
CUSTOM_EMOJI_REGEX = re.compile(
    r"<a?:\w+:\d+>"
)


def _count_unicode_emojis(text):
    """
    Roughly counts Unicode emojis in message text.
    """
    count = 0

    for char in text:
        code = ord(char)

        if (
            0x1F300 <= code <= 0x1FAFF or
            0x1F1E6 <= code <= 0x1F1FF or
            0x2600 <= code <= 0x27BF
        ):
            count += 1

    return count


async def _scan_user(guild: discord.Guild, user: discord.Member):
    total_messages = 0
    total_attachments = 0
    total_images = 0
    total_videos = 0
    total_links = 0
    total_emojis = 0

    # Extra statistics gathered during the same scan
    date_counts = Counter()
    channel_counts = Counter()

    for channel in guild.text_channels:
        perms = channel.permissions_for(guild.me)

        if not perms.read_message_history:
            continue

        try:
            async for message in channel.history(
                limit=None,
                oldest_first=True
            ):
                if message.author.id != user.id:
                    continue

                total_messages += 1

                # Count messages by specific calendar date
                date_counts[
                    message.created_at.date()
                ] += 1

                # Count messages by channel
                channel_counts[channel.name] += 1

                # Count normal URLs
                total_links += len(
                    URL_REGEX.findall(message.content)
                )

                # Count Unicode emojis
                total_emojis += _count_unicode_emojis(
                    message.content
                )

                # Count custom Discord emojis
                total_emojis += len(
                    CUSTOM_EMOJI_REGEX.findall(message.content)
                )

                # Count attachments
                for attachment in message.attachments:
                    total_attachments += 1

                    content_type = attachment.content_type or ""
                    filename = attachment.filename.lower()

                    if content_type.startswith("image/"):
                        total_images += 1

                    elif content_type.startswith("video/"):
                        total_videos += 1

                    else:
                        # Fallback when Discord does not provide
                        # a content type.
                        if filename.endswith((
                            ".png",
                            ".jpg",
                            ".jpeg",
                            ".gif",
                            ".webp",
                            ".bmp",
                            ".tiff",
                            ".svg"
                        )):
                            total_images += 1

                        elif filename.endswith((
                            ".mp4",
                            ".mov",
                            ".avi",
                            ".mkv",
                            ".webm",
                            ".m4v"
                        )):
                            total_videos += 1

        except discord.Forbidden:
            continue

    # Find the single calendar date with the most messages
    if date_counts:
        most_active_day, most_active_day_count = (
            date_counts.most_common(1)[0]
        )

        most_active_day = most_active_day.strftime(
            "%d %B %Y"
        )
    else:
        most_active_day = "Unknown"
        most_active_day_count = 0

    # Find the channel with the most messages
    if channel_counts:
        most_active_channel, most_active_channel_count = (
            channel_counts.most_common(1)[0]
        )
    else:
        most_active_channel = "Unknown"
        most_active_channel_count = 0

    return {
        "total_messages": total_messages,
        "total_attachments": total_attachments,
        "total_images": total_images,
        "total_videos": total_videos,
        "total_links": total_links,
        "total_emojis": total_emojis,
        "most_active_day": most_active_day,
        "most_active_day_count": most_active_day_count,
        "most_active_channel": most_active_channel,
        "most_active_channel_count": most_active_channel_count,
    }


def setup(bot):
    @bot.tree.command(
        name="stats",
        description="show a member's server stats (backdated across full history)"
    )
    @app_commands.describe(
        member="who to look up (defaults to you)"
    )
    async def stats(
        interaction: discord.Interaction,
        member: discord.Member = None
    ):
        member = member or interaction.user
        guild = interaction.guild

        if guild is None:
            await interaction.response.send_message(
                "this only works inside a server",
                ephemeral=True
            )
            return

        # Tell the user the scan has started
        await interaction.response.send_message(
            f"I'm scanning the full message history for "
            f"**{member.display_name}**.\n"
            f"This may take a while on a busy server. "
            f"Please bear with me."
        )

        log.info(
            "stats",
            f"scanning full history for {member} in {guild.name}"
        )

        try:
            # Full history scan
            entry = await _scan_user(guild, member)

            joined_at = member.joined_at or guild.me.joined_at
            now = datetime.now(timezone.utc)

            days_in_server = max(
                (now - joined_at).days,
                0
            )

            weeks_in_server = max(
                days_in_server / 7,
                1
            )

            total_messages = entry["total_messages"]
            total_attachments = entry["total_attachments"]
            total_images = entry["total_images"]
            total_videos = entry["total_videos"]
            total_links = entry["total_links"]
            total_emojis = entry["total_emojis"]

            avg_per_week = round(
                total_messages / weeks_in_server,
                1
            )

            other_attachments = max(
                total_attachments
                - total_images
                - total_videos,
                0
            )

            # Create circular avatar
            avatar_buffer = await image_utils.make_circle_avatar(
                member
            )

            avatar_file = discord.File(
                avatar_buffer,
                filename="avatar.png"
            )

            embed = discord.Embed(
                title=f"Stats for {member.display_name}",
                color=discord.Color.orange(),
            )

            embed.set_thumbnail(
                url="attachment://avatar.png"
            )

            # General statistics
            embed.add_field(
                name="General",
                value=(
                    f"Messages: {total_messages:,}\n"
                    f"Attachments: {total_attachments:,}\n"
                    f"Average messages/week: {avg_per_week:,}\n"
                    f"Days in server: {days_in_server:,}"
                ),
                inline=False
            )

            # Content statistics
            embed.add_field(
                name="Content",
                value=(
                    f"Images: {total_images:,}\n"
                    f"Videos: {total_videos:,}\n"
                    f"Other attachments: {other_attachments:,}\n"
                    f"Links: {total_links:,}\n"
                    f"Emojis: {total_emojis:,}"
                ),
                inline=True
            )

            # Activity statistics
            embed.add_field(
                name="Activity",
                value=(
                    f"Most active day: "
                    f"{entry['most_active_day']}\n"
                    f"Messages that day: "
                    f"{entry['most_active_day_count']:,}\n"
                    f"Top channel: "
                    f"#{entry['most_active_channel']}\n"
                    f"Messages there: "
                    f"{entry['most_active_channel_count']:,}"
                ),
                inline=True
            )

            # Server membership information
            embed.add_field(
                name="Joined server",
                value=(
                    f"<t:{int(joined_at.timestamp())}:D>\n"
                    f"({days_in_server:,} days ago)"
                ),
                inline=False
            )

            embed.set_footer(
                text="Full server history scan"
            )

            # Replace the original scanning message
            # with the completed statistics embed
            await interaction.edit_original_response(
                content=None,
                embed=embed,
                attachments=[avatar_file]
            )

            log.success(
                "stats",
                f"sent stats for {member} "
                f"({total_messages} messages)"
            )

        except Exception as e:
            log.error(
                "stats",
                f"failed to generate stats for {member}: "
                f"{type(e).__name__}: {e}"
            )

            await interaction.edit_original_response(
                content=(
                    "Something went wrong while scanning "
                    f"**{member.display_name}**'s history."
                ),
                embed=None,
                attachments=[]
            )