import discord

META = {"name": "help"}


def setup(bot):
    @bot.tree.command(name="help", description="get help")
    async def help_command(interaction: discord.Interaction):
        await interaction.response.send_message(
            "yo <@752432778947067944> since you cant be bothered to code the help command yet this is your job. lazy ass bee honestly man"
        )