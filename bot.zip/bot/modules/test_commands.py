import os
import io
import discord
from discord import app_commands
from PIL import Image

import terminal_reports as log
import text_templates as text
import image_utils

META = {"name": "test_commands"}

_DIR = os.path.dirname(__file__)
_TEXT_PATH = os.path.join(_DIR, "welcome_text.json")


def _allowed_ids():
    raw = os.getenv("ARCHIVE_USERS", "")
    ids = set()
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            ids.add(int(part))
    return ids


async def _check_archive_user(interaction: discord.Interaction):
    """Returns True if allowed, otherwise sends a rejection and returns False."""
    if interaction.user.id in _allowed_ids():
        return True
    await interaction.response.send_message("You don't have permission to use this.", ephemeral=True)
    log.warn("test_commands", f"{interaction.user} tried to use /test without permission")
    return False


def _average_color(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
    img = img.resize((32, 32))
    r_total = g_total = b_total = a_total = 0
    for r, g, b, a in img.getdata():
        r_total += r * a
        g_total += g * a
        b_total += b * a
        a_total += a
    if a_total == 0:
        return discord.Color.default()
    return discord.Color.from_rgb(
        round(r_total / a_total),
        round(g_total / a_total),
        round(b_total / a_total),
    )


def setup(bot):
    test_group = app_commands.Group(name="test", description="Archive-only test commands")

    @test_group.command(name="welcome", description="Send a fake welcome message as if you just joined")
    async def test_welcome(interaction: discord.Interaction):
        if not await _check_archive_user(interaction):
            return

        strings = text.load(_TEXT_PATH)
        placeholders = {
            "member": interaction.user.mention,
            "server name": interaction.guild.name,
            "member count": interaction.guild.member_count,
        }
        welcome_text = text.render_all(strings["welcome"], placeholders)

        avatar_buffer = await image_utils.make_circle_avatar(interaction.user)
        embed_color = _average_color(avatar_buffer.getvalue())
        avatar_buffer.seek(0)
        avatar_file = discord.File(avatar_buffer, filename="avatar.png")

        embed = discord.Embed(
            title=welcome_text["title"],
            description=welcome_text["body"],
            color=embed_color,
        )
        embed.set_thumbnail(url="attachment://avatar.png")
        embed.set_footer(text=welcome_text["footer"])

        await interaction.response.send_message(embed=embed, file=avatar_file)
        log.success("test_commands", f"{interaction.user} ran /test welcome in #{interaction.channel}")

    @test_group.command(name="milestone", description="Send a test milestone message with a chosen member count")
    @app_commands.describe(count="The member count to announce")
    async def test_milestone(interaction: discord.Interaction, count: int):
        if not await _check_archive_user(interaction):
            return

        strings = text.load(_TEXT_PATH)
        milestone_text = text.render(strings["milestone"]["body"], {"member count": count})

        await interaction.response.send_message(milestone_text)
        log.success("test_commands", f"{interaction.user} ran /test milestone with count={count}")

    bot.tree.add_command(test_group)