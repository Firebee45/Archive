import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import discord
from discord import app_commands
from terminal_reports import error, info, success, warn

META = {"name": "project"}

PROJECT_ADMIN_ID = int(os.getenv("PROJECT_ADMIN_ID", "752432778947067944"))
PROJECT_FORUM_ID = 1433362494025629797
OUTER_ROOT = Path(__file__).resolve().parents[2]
PROJECTS_ROOT = OUTER_ROOT / "Projects"
LISTING_ROOT = PROJECTS_ROOT / "listing-data"
MANIFEST_FILE = LISTING_ROOT / "manifest.json"
REPLIES_FILE = Path(__file__).with_name("project_replies.json")
PROJECT_DEBUG = os.getenv("PROJECT_DEBUG", "0") == "1"

SETUP_FIELDS = {
    "title": "title",
    "description": "description",
    "status": "status",
    "tags": "tags",
}


def admin_only(interaction):
    allowed = interaction.user.id == PROJECT_ADMIN_ID
    debug(f"permission user={interaction.user.id} allowed={allowed}")
    return allowed


def debug(message):
    if PROJECT_DEBUG:
        info("project-debug", message)


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (FileNotFoundError, json.JSONDecodeError):
        debug(f"json fallback path={path}")
        return default


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2)


def reply(command, key, **values):
    templates = load_json(REPLIES_FILE, {})
    entry = templates.get(command, {}).get(key, key)
    template = entry.get("text", key) if isinstance(entry, dict) else entry
    debug(f"reply command={command} key={key} template_found={entry != key}")
    return template.format(**values)


def reply_is_global(command, key):
    entry = load_json(REPLIES_FILE, {}).get(command, {}).get(key, {})
    return isinstance(entry, dict) and entry.get("isglobal", 0) == 1


def slugify(value):
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-") or "project"


def project_path(slug):
    return LISTING_ROOT / slug


def project_file(slug):
    return project_path(slug) / "project.md"


def timeline_manifest(slug):
    return project_path(slug) / "timeline" / "manifest.json"


def parse_project_file(path):
    values = {}
    if not path.exists():
        return values
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            match = re.match(r"^([^:]+):\s*(.+)$", line.strip())
            if match:
                values[match.group(1).strip().lower()] = match.group(2).strip()
            if line.startswith("## "):
                break
    return values


def find_project_by_thread(thread_id):
    for path in LISTING_ROOT.glob("*/project.md"):
        values = parse_project_file(path)
        if values.get("dev channel id") == str(thread_id):
            debug(f"project found thread={thread_id} slug={path.parent.name}")
            return path.parent.name
    debug(f"project missing thread={thread_id}")
    return None


def write_project_file(slug, data):
    folder = project_path(slug)
    (folder / "assets").mkdir(parents=True, exist_ok=True)
    (folder / "timeline").mkdir(parents=True, exist_ok=True)
    if not timeline_manifest(slug).exists():
        save_json(timeline_manifest(slug), [])

    lines = [
        f"Title: {data['title']}",
        f"Status: {data.get('status') or 'Active'}",
        f"Updated: {data.get('updated') or 'Not updated yet'}",
        f"Tags: {data.get('tags') or ''}",
        f"Dev Channel: {data['dev_channel_url']}",
        f"Dev Channel ID: {data['dev_channel_id']}",
        "IsLocal: 1",
        f"Image: {data.get('image') or ''}",
        "",
        "## Description",
        data.get("description") or "",
        "",
        "## Involved",
    ]
    for profile in data.get("involved_profiles", []):
        lines.append(f"<!-- discord-profile: {json.dumps(profile, separators=(',', ':'))} -->")
    for entry in data.get("involved", []):
        lines.append(f"- {entry}")
    lines.extend(["", "## Core Ideas"])
    lines.extend(f"- {idea}" for idea in data.get("ideas", []))
    lines.extend(["", "## Details"])
    lines.extend(f"- {detail}" for detail in data.get("details", []))
    lines.extend(["", "## Tech", ""])
    project_file(slug).write_text("\n".join(lines), encoding="utf-8")

    manifest = load_json(MANIFEST_FILE, [])
    relative = f"{slug}/project.md"
    if relative not in manifest:
        manifest.append(relative)
    save_json(MANIFEST_FILE, manifest)
    success("project", f"created slug={slug} path={project_file(slug)}")


async def get_forum(bot):
    channel = bot.get_channel(PROJECT_FORUM_ID)
    if channel is None:
        channel = await bot.fetch_channel(PROJECT_FORUM_ID)
    is_forum = isinstance(channel, discord.ForumChannel)
    debug(f"forum lookup id={PROJECT_FORUM_ID} found={channel is not None} is_forum={is_forum}")
    return channel if is_forum else None


async def find_message_in_forum(bot, forum, message_id):
    threads = list(forum.threads)
    try:
        async for thread in forum.archived_threads(limit=None):
            if thread.id not in {item.id for item in threads}:
                threads.append(thread)
    except discord.HTTPException:
        warn("project", "could not enumerate archived project threads")

    debug(f"message search id={message_id} threads={len(threads)}")

    for thread in threads:
        try:
            message = await thread.fetch_message(message_id)
            debug(f"message found id={message_id} thread={thread.id}")
            return thread, message
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            continue
    debug(f"message missing id={message_id}")
    return None, None


async def find_message_in_dm(user, message_id):
    try:
        dm = await user.create_dm()
        message = await dm.fetch_message(message_id)
        debug(f"message found in admin DM id={message_id}")
        return dm, message
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        debug(f"message missing in admin DM id={message_id}")
        return None, None


def safe_filename(name):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name)[:120] or "attachment"


async def download_attachments(message, assets_dir):
    links = []
    for attachment in message.attachments:
        filename = safe_filename(attachment.filename)
        target = assets_dir / filename
        suffix = 1
        while target.exists():
            target = assets_dir / f"{Path(filename).stem}_{suffix}{Path(filename).suffix}"
            suffix += 1
        try:
            await attachment.save(target)
            relative = f"../assets/{quote(target.name)}"
            links.append((attachment, relative))
            debug(f"attachment saved name={target.name} path={target}")
        except (discord.HTTPException, OSError):
            links.append((attachment, attachment.url))
            warn("project", f"attachment fallback url name={attachment.filename}")
    return links


def attachment_markdown(attachments):
    output = []
    for attachment, link in attachments:
        if attachment.content_type and attachment.content_type.startswith("image/"):
            output.append(f"![{attachment.filename}]({link})")
        else:
            output.append(f"[{attachment.filename}]({link})")
    return "\n".join(output)


def forwarded_source(message):
    snapshots = getattr(message, "message_snapshots", None) or []
    if snapshots:
        debug(f"forwarded message detected id={message.id} snapshots={len(snapshots)}")
        return snapshots[0]
    return message


async def append_involved(slug, user, contribution):
    path = project_file(slug)
    text = path.read_text(encoding="utf-8")
    marker = "## Involved"
    entry = f"- {user.id}: {contribution}"
    if entry not in text:
        profile = {
            "id": str(user.id),
            "name": user.global_name or user.name,
            "avatar": user.display_avatar.url,
        }
        metadata = f"<!-- discord-profile: {json.dumps(profile, separators=(',', ':'))} -->"
        text = text.replace(marker, f"{marker}\n{metadata}\n{entry}", 1)
        path.write_text(text, encoding="utf-8")
        success("project", f"involved added slug={slug} user={user.id}")
    else:
        debug(f"involved already present slug={slug} user={user.id}")


def append_timeline(slug, source, forwarded_message, project_thread, attachment_links):
    date = source.created_at.astimezone(timezone.utc).date().isoformat()
    timestamp = source.created_at.astimezone(timezone.utc).isoformat()
    folder = project_path(slug)
    path = folder / "timeline" / f"{date}.md"
    body = (source.content or "").strip() or "_No text was included in this update._"
    channel_link = getattr(forwarded_message, "jump_url", None) or project_thread.jump_url
    entry = f"<!-- update-timestamp: {timestamp} -->\n{body}\n\n[View Discord message]({channel_link})"
    media = attachment_markdown(attachment_links) if attachment_links else ""
    if path.exists():
        existing = path.read_text(encoding="utf-8").replace("## Update\n\n", "").rstrip()
        old_media = re.findall(r"(?:^|\n)## Media\s*\n([\s\S]*?)(?=\n## |\Z)", existing)
        media_lines = []
        for block in old_media:
            media_lines.extend(line.strip() for line in block.splitlines() if line.strip())
        media_lines.extend(line.strip() for line in media.splitlines() if line.strip())
        media_lines = list(dict.fromkeys(media_lines))
        existing = re.sub(r"(?:^|\n)## Media\s*\n[\s\S]*?(?=\n## |\Z)", "", existing).rstrip()
        entries = []
        for chunk in re.split(r"(?=<!--\s*update-timestamp:\s*[^>]+-->)", existing):
            chunk = chunk.strip()
            if chunk:
                match = re.search(r"<!--\s*update-timestamp:\s*([^>]+?)\s*-->", chunk)
                entries.append((match.group(1).strip() if match else "", chunk))
        entries.append((timestamp, entry))
        entries.sort(key=lambda item: item[0], reverse=True)
        content = "\n\n".join(chunk for _, chunk in entries)
    else:
        content = entry

        media_lines = [line.strip() for line in media.splitlines() if line.strip()]

    if media_lines:
        content += "\n\n## Media\n\n" + "\n".join(media_lines)
    path.write_text(content.rstrip() + "\n", encoding="utf-8")

    dates = load_json(timeline_manifest(slug), [])
    filename = f"{date}.md"
    if filename not in dates:
        dates.append(filename)
        dates.sort(reverse=True)
        save_json(timeline_manifest(slug), dates)

    text = project_file(slug).read_text(encoding="utf-8")
    text = re.sub(r"^Updated:.*$", f"Updated: {date}", text, count=1, flags=re.MULTILINE)
    project_file(slug).write_text(text, encoding="utf-8")
    success("project", f"timeline written slug={slug} date={date} attachments={len(attachment_links)}")


def set_project_status(slug, status):
    path = project_file(slug)
    text = path.read_text(encoding="utf-8")
    updated = re.sub(r"^Status:.*$", f"Status: {status}", text, count=1, flags=re.MULTILINE)
    path.write_text(updated, encoding="utf-8")
    success("project", f"status updated slug={slug} status={status}")


async def change_status(interaction, status):
    if not admin_only(interaction):
        command = f"/project {status.lower().replace(' ', '')}"
        await interaction.response.send_message(reply(command, "not_allowed"), ephemeral=not reply_is_global(command, "not_allowed"))
        return

    state = getattr(interaction.client, "project_setup", None)
    if state and state["user_id"] == interaction.user.id and state["thread_id"] == interaction.channel.id:
        state["data"]["status"] = status
        command = f"/project {status.lower().replace(' ', '')}"
        await interaction.response.send_message(reply(command, "saved"), ephemeral=not reply_is_global(command, "saved"))
        return

    if not isinstance(interaction.channel, discord.Thread) or interaction.channel.parent_id != PROJECT_FORUM_ID:
        command = f"/project {status.lower().replace(' ', '')}"
        await interaction.response.send_message(reply(command, "wrong_forum"), ephemeral=not reply_is_global(command, "wrong_forum"))
        return

    slug = find_project_by_thread(interaction.channel.id)
    if not slug:
        command = f"/project {status.lower().replace(' ', '')}"
        await interaction.response.send_message(reply(command, "not_started"), ephemeral=not reply_is_global(command, "not_started"))
        return

    set_project_status(slug, status)
    command = f"/project {status.lower().replace(' ', '')}"
    await interaction.response.send_message(reply(command, "updated", slug=slug), ephemeral=not reply_is_global(command, "updated"))


def setup_group(bot):
    group = app_commands.Group(name="project", description="Manage the Projects development archive")
    info("project", f"registering commands forum={PROJECT_FORUM_ID} admin={PROJECT_ADMIN_ID}")

    async def reject(interaction):
        await interaction.response.send_message(reply("/project setup", "not_allowed"), ephemeral=not reply_is_global("/project setup", "not_allowed"))

    @group.command(name="setup", description="Start a private project setup")
    async def setup_project(interaction: discord.Interaction):
        debug(f"setup invoked user={interaction.user.id} channel={interaction.channel.id}")
        if not admin_only(interaction):
            await reject(interaction)
            return
        forum = await get_forum(bot)
        if forum is None:
            await interaction.response.send_message(reply("/project setup", "forum_missing", forum_id=PROJECT_FORUM_ID), ephemeral=not reply_is_global("/project setup", "forum_missing"))
            return
        if not isinstance(interaction.channel, discord.Thread) or interaction.channel.parent_id != PROJECT_FORUM_ID:
            await interaction.response.send_message(reply("/project setup", "wrong_forum"), ephemeral=not reply_is_global("/project setup", "wrong_forum"))
            return
        owner_profile = {"id": str(interaction.user.id), "name": interaction.user.global_name or interaction.user.name, "avatar": interaction.user.display_avatar.url}
        bot.project_setup = {"user_id": interaction.user.id, "thread_id": interaction.channel.id, "data": {"dev_channel_id": interaction.channel.id, "dev_channel_url": interaction.channel.jump_url, "involved": [f"{interaction.user.id}: Project owner"], "involved_profiles": [owner_profile]}}
        await interaction.response.send_message(reply("/project setup", "started"), ephemeral=not reply_is_global("/project setup", "started"))

    @group.command(name="title", description="Set the pending project title")
    @app_commands.describe(value="Project title")
    async def title(interaction: discord.Interaction, value: str):
        await update_setup_field(interaction, "title", value)

    @group.command(name="description", description="Set the pending project description")
    @app_commands.describe(value="Project description")
    async def description(interaction: discord.Interaction, value: str):
        await update_setup_field(interaction, "description", value)

    @group.command(name="status", description="Set the pending project status")
    @app_commands.describe(value="Active, Finished, or Abandoned")
    async def status(interaction: discord.Interaction, value: str):
        await update_setup_field(interaction, "status", value)

    @group.command(name="onhold", description="Mark the current project as on hold")
    async def onhold(interaction: discord.Interaction):
        await change_status(interaction, "On hold")

    @group.command(name="abandoned", description="Mark the current project as abandoned")
    async def abandoned(interaction: discord.Interaction):
        await change_status(interaction, "Abandoned")

    @group.command(name="finished", description="Mark the current project as finished")
    async def finished(interaction: discord.Interaction):
        await change_status(interaction, "Finished")

    @group.command(name="tags", description="Set project tags")
    @app_commands.describe(value="Comma-separated tags")
    async def tags(interaction: discord.Interaction, value: str):
        await update_setup_field(interaction, "tags", value)

    @group.command(name="ideas", description="Set the project's core ideas")
    @app_commands.describe(value="Comma-separated core ideas")
    async def ideas(interaction: discord.Interaction, value: str):
        await update_setup_field(interaction, "ideas", [item.strip() for item in value.split(",") if item.strip()])

    @group.command(name="details", description="Set the project's details")
    @app_commands.describe(value="Comma-separated project details")
    async def details(interaction: discord.Interaction, value: str):
        await update_setup_field(interaction, "details", [item.strip() for item in value.split(",") if item.strip()])

    @group.command(name="cover", description="Set the project cover image from a Discord media URL")
    @app_commands.describe(url="Direct Discord CDN image URL")
    async def cover(interaction: discord.Interaction, url: str):
        if not admin_only(interaction):
            await interaction.response.send_message(reply("/project cover", "not_allowed"), ephemeral=not reply_is_global("/project cover", "not_allowed"))
            return
        if not re.match(r"^https://(?:cdn\.|media\.)?discord(?:app\.com|app\.net)/", url):
            await interaction.response.send_message(reply("/project cover", "invalid_url"), ephemeral=not reply_is_global("/project cover", "invalid_url"))
            return
        await update_setup_field(interaction, "image", url, command="/project cover")

    @group.command(name="add", description="Add a Discord user to the involved list")
    @app_commands.describe(user="User to add", contribution="What they did")
    async def add(interaction: discord.Interaction, user: discord.User, contribution: str = "Contributor"):
        debug(f"add invoked user={interaction.user.id} target={user.id} channel={interaction.channel.id}")
        if not admin_only(interaction):
            await interaction.response.send_message(reply("/project add", "not_allowed"), ephemeral=not reply_is_global("/project add", "not_allowed"))
            return
        if not isinstance(interaction.channel, discord.Thread) or interaction.channel.parent_id != PROJECT_FORUM_ID:
            await interaction.response.send_message(reply("/project add", "wrong_forum"), ephemeral=not reply_is_global("/project add", "wrong_forum"))
            return
        state = getattr(bot, "project_setup", None)
        if state and state["user_id"] == interaction.user.id and state["thread_id"] == interaction.channel.id:
            entry = f"{user.id}: {contribution}"
            if entry not in state["data"].setdefault("involved", []):
                state["data"]["involved"].append(entry)
                state["data"].setdefault("involved_profiles", []).append({
                    "id": str(user.id),
                    "name": user.global_name or user.name,
                    "avatar": user.display_avatar.url,
                })
            debug(f"involved queued slug=pending user={user.id}")
        else:
            slug = find_project_by_thread(interaction.channel.id)
            if not slug:
                await interaction.response.send_message(reply("/project add", "not_started"), ephemeral=not reply_is_global("/project add", "not_started"))
                return
            await append_involved(slug, user, contribution)
        await interaction.response.send_message(reply("/project add", "added", mention=user.mention), ephemeral=not reply_is_global("/project add", "added"))

    @group.command(name="update", description="Import a forum message into the project timeline")
    @app_commands.describe(message_id="One message ID or comma-separated message IDs")
    async def update(interaction: discord.Interaction, message_id: str):
        debug(f"update invoked user={interaction.user.id} message={message_id} channel={interaction.channel.id}")
        if not admin_only(interaction):
            await interaction.response.send_message(reply("/project update", "not_allowed"), ephemeral=not reply_is_global("/project update", "not_allowed"))
            return
        message_ids = list(dict.fromkeys(item.strip() for item in message_id.split(",") if item.strip()))
        if not message_ids or not all(item.isdigit() for item in message_ids):
            await interaction.response.send_message(reply("/project update", "invalid_id"), ephemeral=not reply_is_global("/project update", "invalid_id"))
            return
        await interaction.response.defer(ephemeral=not reply_is_global("/project update", "imported"))
        if not isinstance(interaction.channel, discord.Thread) or interaction.channel.parent_id != PROJECT_FORUM_ID:
            await interaction.followup.send(reply("/project update", "not_project"), ephemeral=not reply_is_global("/project update", "not_project"))
            return
        slug = find_project_by_thread(interaction.channel.id)
        if not slug:
            await interaction.followup.send(reply("/project update", "not_project"), ephemeral=not reply_is_global("/project update", "not_project"))
            return

        forum = await get_forum(bot)
        imported = 0
        attachment_count = 0
        imported_dates = []
        missing = []
        assets = project_path(slug) / "assets"
        assets.mkdir(parents=True, exist_ok=True)
        for current_id in message_ids:
            source_thread, message = await find_message_in_forum(bot, forum, int(current_id)) if forum else (None, None)
            source_location = "forum"
            if not message:
                source_thread, message = await find_message_in_dm(interaction.user, int(current_id))
                source_location = "admin DM"
            if not message:
                missing.append(current_id)
                continue
            debug(f"update source={source_location} project={slug} message={current_id}")
            source = forwarded_source(message)
            links = await download_attachments(source, assets)
            append_timeline(slug, source, message, interaction.channel, links)
            imported += 1
            attachment_count += len(links)
            imported_dates.append(source.created_at.date().isoformat())

        if not imported:
            await interaction.followup.send(reply("/project update", "message_missing"), ephemeral=not reply_is_global("/project update", "message_missing"))
            return
        await interaction.followup.send(reply("/project update", "imported", date=", ".join(sorted(set(imported_dates))), dates=", ".join(sorted(set(imported_dates))), slug=slug, attachments=attachment_count, messages=imported, missing=", ".join(missing) or "none"), ephemeral=not reply_is_global("/project update", "imported"))

    @group.command(name="done", description="Finish the private project setup")
    async def done(interaction: discord.Interaction):
        debug(f"done invoked user={interaction.user.id} channel={interaction.channel.id}")
        if not admin_only(interaction):
            await interaction.response.send_message(reply("/project done", "not_allowed"), ephemeral=not reply_is_global("/project done", "not_allowed"))
            return
        state = getattr(bot, "project_setup", None)
        if not state or state["user_id"] != interaction.user.id or state["thread_id"] != interaction.channel.id:
            await interaction.response.send_message(reply("/project done", "no_setup"), ephemeral=not reply_is_global("/project done", "no_setup"))
            return
        data = state["data"]
        if not data.get("title") or not data.get("description"):
            await interaction.response.send_message(reply("/project done", "missing_required"), ephemeral=not reply_is_global("/project done", "missing_required"))
            return
        slug = slugify(data["title"])
        write_project_file(slug, data)
        del bot.project_setup
        await interaction.response.send_message(reply("/project done", "created", slug=slug), ephemeral=not reply_is_global("/project done", "created"))

    bot.tree.add_command(group)


async def update_setup_field(interaction, field, value, command=None):
    command = command or f"/project {field}"
    if not admin_only(interaction):
        await interaction.response.send_message(reply(command, "not_allowed"), ephemeral=not reply_is_global(command, "not_allowed"))
        return
    state = getattr(interaction.client, "project_setup", None)
    if not state or state["user_id"] != interaction.user.id or state["thread_id"] != interaction.channel.id:
        await interaction.response.send_message(reply(command, "not_started"), ephemeral=not reply_is_global(command, "not_started"))
        return
    state["data"][field] = value
    await interaction.response.send_message(reply(command, "saved"), ephemeral=not reply_is_global(command, "saved"))


def setup(bot):
    setup_group(bot)
    success("project", "command group registered")
