import discord, os, json, re
from discord import app_commands
from PIL import Image

META = {"name": "archive"}

ALLOWED_USERS = [int(x) for x in os.getenv("ARCHIVE_USERS", "").split(",") if x]

OUTER_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
SITE_ROOT = os.path.join(OUTER_ROOT, "Archive")
LISTING_DIR = os.path.join(SITE_ROOT, "listing-data")
MEDIA_DIR = os.path.join(SITE_ROOT, "assets", "media")
DOWNLOADS_DIR = os.path.join(SITE_ROOT, "assets", "downloads")
DATA_DIR = os.path.join(LISTING_DIR, "_data")
TAGS_FILE = os.path.join(LISTING_DIR, "tag-colours.md")
CONFIG_FILE = os.path.join(SITE_ROOT, "archive_config.json")
THREADS_FILE = os.path.join(SITE_ROOT, "archive_threads.json")
MANIFEST_FILE = os.path.join(LISTING_DIR, "manifest.json")

EXT_FOLDERS = {
    ".mcworld": "be-world",
    ".mcstructure": "structure",
    ".litematic": "litematic",
    ".zip": "je-world",
}

FIELDS = ["title", "version", "tags", "description", "credits", "features", "downsides", "notes", "cover", "gallery", "downloads"]


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def unique_filename(folder, filename):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    if not os.path.exists(path):
        return filename
    name, ext = os.path.splitext(filename)
    n = 1
    while True:
        candidate = f"{name}_{n}{ext}"
        if not os.path.exists(os.path.join(folder, candidate)):
            return candidate
        n += 1


def pad_to_square(path):
    img = Image.open(path)
    w, h = img.size
    if w == h:
        return
    size = max(w, h)
    if img.mode != "RGBA":
        img = img.convert("RGBA")
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.paste(img, ((size - w) // 2, (size - h) // 2), img)
    canvas.save(path)


def load_json(path, default):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)


def load_tags():
    if not os.path.exists(TAGS_FILE):
        return []
    names = []
    with open(TAGS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            m = re.match(r"^-\s*([^:]+):", line)
            if m:
                names.append(m.group(1).strip())
    return names


def append_tag(name):
    os.makedirs(os.path.dirname(TAGS_FILE), exist_ok=True)
    with open(TAGS_FILE, "a", encoding="utf-8") as f:
        f.write(f"- {name}: ⬜ #ffffff\n")


def build_md(data):
    md = f"# {data['title']}\n"
    if data.get("cover"):
        md += f"![cover](assets/media/{data['cover']})\n"
    md += "\n"
    meta = []
    if data.get("version"):
        meta.append(f"Version: {data['version']}")
    if data.get("tags"):
        meta.append(f"Tags: {data['tags']}")
    if meta:
        md += "\n".join(meta) + "\n\n"
    if data.get("description"):
        md += f"{data['description']}\n\n"
    if data.get("credits"):
        md += "## Credits\n" + "\n".join(f"- {c}" for c in data["credits"]) + "\n\n"
    if data.get("features"):
        md += "## Features\n" + "\n".join(f"- {f}" for f in data["features"]) + "\n\n"
    if data.get("downsides"):
        md += "## Downsides\n" + "\n".join(f"- {d}" for d in data["downsides"]) + "\n\n"
    if data.get("notes"):
        md += f"## Notes\n{data['notes']}\n\n"
    if data.get("gallery"):
        md += "## Gallery\n" + "\n".join(f"![](assets/media/{g})" for g in data["gallery"]) + "\n\n"
    if data.get("downloads"):
        md += "## Downloads\n" + "\n".join(f"- [{d['filename']}](assets/downloads/{d['subfolder']}/{d['filename']})" for d in data["downloads"]) + "\n\n"
    return md.rstrip() + "\n"


def build_discord_message(data):
    parts = [f"**{data['title']}**"]
    meta = []
    if data.get("version"):
        meta.append(f"Version: {data['version']}")
    if data.get("tags"):
        meta.append(f"Tags: {data['tags']}")
    if meta:
        parts.append("\n".join(meta))
    if data.get("description"):
        parts.append(data["description"])
    if data.get("credits"):
        parts.append("**Credits**\n" + "\n".join(f"- {c}" for c in data["credits"]))
    if data.get("features"):
        parts.append("**Features**\n" + "\n".join(f"- {f}" for f in data["features"]))
    if data.get("downsides"):
        parts.append("**Downsides**\n" + "\n".join(f"- {d}" for d in data["downsides"]))
    if data.get("notes"):
        parts.append(f"**Notes**\n{data['notes']}")
    return "\n\n".join(parts)


def parse_md(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    data = {"title": None, "cover": None, "version": None, "tags": None,
            "description": None, "credits": [], "features": [], "downsides": [],
            "notes": None, "gallery": [], "downloads": []}

    lines = text.split("\n")
    i = 0

    if lines and lines[0].startswith("# "):
        data["title"] = lines[0][2:].strip()
        i = 1

    cover_match = re.match(r"!\[cover\]\(assets/media/(.+)\)", lines[i].strip()) if i < len(lines) else None
    if cover_match:
        data["cover"] = cover_match.group(1)
        i += 1

    while i < len(lines) and not lines[i].strip():
        i += 1

    while i < len(lines) and lines[i].strip() and not lines[i].startswith("##"):
        line = lines[i].strip()
        if line.lower().startswith("version:"):
            data["version"] = line.split(":", 1)[1].strip()
        elif line.lower().startswith("tags:"):
            data["tags"] = line.split(":", 1)[1].strip()
        i += 1

    while i < len(lines) and not lines[i].strip():
        i += 1

    desc_lines = []
    while i < len(lines) and not lines[i].startswith("##"):
        desc_lines.append(lines[i])
        i += 1
    data["description"] = "\n".join(desc_lines).strip() or None

    current_section = None
    notes_lines = []
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("## "):
            current_section = stripped[3:].strip().lower()
            i += 1
            continue
        if current_section == "credits" and stripped.startswith("- "):
            data["credits"].append(stripped[2:].strip())
        elif current_section == "features" and stripped.startswith("- "):
            data["features"].append(stripped[2:].strip())
        elif current_section == "downsides" and stripped.startswith("- "):
            data["downsides"].append(stripped[2:].strip())
        elif current_section == "notes" and stripped:
            notes_lines.append(stripped)
        elif current_section == "gallery" and stripped:
            m = re.match(r"!\[\]\(assets/media/(.+)\)", stripped)
            if m:
                data["gallery"].append(m.group(1))
        elif current_section == "downloads" and stripped.startswith("- "):
            m = re.match(r"-\s*\[(.+?)\]\(assets/downloads/([^/]+)/(.+)\)", stripped)
            if m:
                data["downloads"].append({"filename": m.group(3), "subfolder": m.group(2)})
        i += 1

    data["notes"] = "\n".join(notes_lines).strip() or None
    return data


async def ask_optional(interaction, bot, check, prompt):
    await interaction.channel.send(f"{prompt} (or n/a to skip)")
    msg = await bot.wait_for("message", check=check, timeout=600)
    content = msg.content.strip()
    return None if content.lower() == "n/a" else content


async def ask_list_optional(interaction, bot, check, prompt):
    await interaction.channel.send(f"{prompt}\nsend one item per message, type done when finished, or n/a to skip")
    items = []
    while True:
        msg = await bot.wait_for("message", check=check, timeout=600)
        content = msg.content.strip()
        low = content.lower()
        if low == "n/a":
            return []
        if low == "done":
            return items
        items.append(content)


async def ask_media_optional(interaction, bot, check, prompt, folder):
    await interaction.channel.send(f"{prompt}\nsend one file per message, type done when finished, or n/a to skip")
    items = []
    while True:
        msg = await bot.wait_for("message", check=check, timeout=600)
        content = msg.content.strip().lower()
        if content == "n/a":
            return []
        if content == "done":
            return items
        if msg.attachments:
            for att in msg.attachments:
                final_name = unique_filename(folder, att.filename)
                full_path = os.path.join(folder, final_name)
                await att.save(full_path)
                pad_to_square(full_path)
                items.append(final_name)


async def ask_downloads_optional(interaction, bot, check, prompt):
    await interaction.channel.send(f"{prompt}\nsend one file per message, type done when finished, or n/a to skip")
    items = []
    while True:
        msg = await bot.wait_for("message", check=check, timeout=600)
        content = msg.content.strip().lower()
        if content == "n/a":
            return []
        if content == "done":
            return items
        if not msg.attachments:
            await interaction.channel.send("please send a file attachment, or type done/n/a")
            continue
        att = msg.attachments[0]
        ext = os.path.splitext(att.filename)[1].lower()
        subfolder = EXT_FOLDERS.get(ext)
        if not subfolder:
            await interaction.channel.send(f"unrecognised file type {ext}, which folder? (be-world, je-world, litematic, structure)")
            folder_msg = await bot.wait_for("message", check=check, timeout=600)
            subfolder = folder_msg.content.strip().lower()
        target_dir = os.path.join(DOWNLOADS_DIR, subfolder)
        final_name = unique_filename(target_dir, att.filename)
        await att.save(os.path.join(target_dir, final_name))
        items.append({"filename": final_name, "subfolder": subfolder})


async def edit_list_field(interaction, bot, check, current, label):
    items = list(current)
    while True:
        listing = "\n".join(f"{i+1}. {v}" for i, v in enumerate(items)) or "(empty)"
        await interaction.channel.send(
            f"current {label}:\n{listing}\n\n"
            f"reply with numbers to remove (e.g. 1,3), 'clear' to remove all, 'add' to add items, or 'done' to finish"
        )
        msg = await bot.wait_for("message", check=check, timeout=600)
        content = msg.content.strip().lower()
        if content == "done":
            return items
        if content == "clear":
            await interaction.channel.send(f"type confirm to clear all {label} (this removes the whole section)")
            confirm_msg = await bot.wait_for("message", check=check, timeout=600)
            if confirm_msg.content.strip().lower() == "confirm":
                return []
            continue
        if content == "add":
            new_items = await ask_list_optional(interaction, bot, check, f"send new {label} to add")
            items.extend(new_items)
            continue
        try:
            nums = sorted({int(x.strip()) for x in content.split(",")}, reverse=True)
            for n in nums:
                if 1 <= n <= len(items):
                    items.pop(n - 1)
        except ValueError:
            await interaction.channel.send("didn't understand that, use numbers, 'add', or 'done'")


async def edit_media_field(interaction, bot, check, current, folder, label):
    items = list(current)
    while True:
        listing = "\n".join(f"{i+1}. {v}" for i, v in enumerate(items)) or "(empty)"
        await interaction.channel.send(
            f"current {label}s:\n{listing}\n\n"
            f"reply with numbers to remove (e.g. 1,3), 'clear' to remove all, 'add' to add files, or 'done' to finish"
        )
        msg = await bot.wait_for("message", check=check, timeout=600)
        content = msg.content.strip().lower()
        if content == "done":
            return items
        if content == "clear":
            await interaction.channel.send(f"type confirm to clear all {label}s (this removes the whole section)")
            confirm_msg = await bot.wait_for("message", check=check, timeout=600)
            if confirm_msg.content.strip().lower() == "confirm":
                return []
            continue
        if content == "add":
            new_items = await ask_media_optional(interaction, bot, check, f"send new {label}s to add", folder)
            items.extend(new_items)
            continue
        try:
            nums = sorted({int(x.strip()) for x in content.split(",")}, reverse=True)
            for n in nums:
                if 1 <= n <= len(items):
                    items.pop(n - 1)
        except ValueError:
            await interaction.channel.send("didn't understand that, use numbers, 'add', or 'done'")


async def edit_downloads_field(interaction, bot, check, current):
    items = list(current)
    while True:
        listing = "\n".join(f"{i+1}. {v['filename']}" for i, v in enumerate(items)) or "(empty)"
        await interaction.channel.send(
            f"current downloads:\n{listing}\n\n"
            f"reply with numbers to remove (e.g. 1,3), 'clear' to remove all, 'add' to add files, or 'done' to finish"
        )
        msg = await bot.wait_for("message", check=check, timeout=600)
        content = msg.content.strip().lower()
        if content == "done":
            return items
        if content == "clear":
            await interaction.channel.send("type confirm to clear all downloads (this removes the whole section)")
            confirm_msg = await bot.wait_for("message", check=check, timeout=600)
            if confirm_msg.content.strip().lower() == "confirm":
                return []
            continue
        if content == "add":
            new_items = await ask_downloads_optional(interaction, bot, check, "send new download files to add")
            items.extend(new_items)
            continue
        try:
            nums = sorted({int(x.strip()) for x in content.split(",")}, reverse=True)
            for n in nums:
                if 1 <= n <= len(items):
                    items.pop(n - 1)
        except ValueError:
            await interaction.channel.send("didn't understand that, use numbers, 'add', or 'done'")


async def ask_tags(interaction, bot, check):
    known = load_tags()
    known_display = ", ".join(known) if known else "none yet"
    await interaction.channel.send(f"add tags, comma separated (or n/a to skip)\nexisting tags: {known_display}")
    msg = await bot.wait_for("message", check=check, timeout=600)
    content = msg.content.strip()
    if content.lower() == "n/a":
        return None
    entered = [t.strip() for t in content.split(",") if t.strip()]
    for t in entered:
        if t not in known:
            append_tag(t)
    return ", ".join(entered)


async def get_channel(bot):
    config = load_json(CONFIG_FILE, {})
    if "channel_id" in config:
        ch = bot.get_channel(config["channel_id"])
        if ch is None:
            ch = await bot.fetch_channel(config["channel_id"])
        return ch
    return None


def build_files(data):
    files = [discord.File(os.path.join(MEDIA_DIR, g)) for g in data.get("gallery", [])]
    files += [discord.File(os.path.join(DOWNLOADS_DIR, d["subfolder"], d["filename"])) for d in data.get("downloads", [])]
    return files


def resolve_forum_tags(channel, tags_string):
    if not tags_string:
        return []
    typed = [t.strip().lower() for t in tags_string.split(",") if t.strip()]
    matched = []
    for available in channel.available_tags:
        if available.name.strip().lower() in typed:
            matched.append(available)
    return matched


async def upsert_forum_post(bot, channel, md_filename, title, content, files, applied_tags=None):
    threads = load_json(THREADS_FILE, {})
    entry = threads.get(md_filename)
    if entry:
        try:
            thread = bot.get_channel(entry["thread_id"]) or await bot.fetch_channel(entry["thread_id"])
            message_id = entry.get("message_id", entry["thread_id"])
            starter = await thread.fetch_message(message_id)
            await starter.edit(content=content, attachments=files)
            if applied_tags is not None:
                await thread.edit(applied_tags=applied_tags)
            return thread
        except (discord.NotFound, discord.Forbidden) as e:
            print(f"upsert_forum_post: couldn't edit existing post for {md_filename} ({e!r}), creating a new one instead")
    result = await channel.create_thread(name=title, content=content, files=files, applied_tags=applied_tags or [])
    threads[md_filename] = {"channel_id": channel.id, "thread_id": result.thread.id, "message_id": result.message.id}
    save_json(THREADS_FILE, threads)
    return result.thread

def setup(bot):
    @bot.tree.command(name="archive", description="create an archive post")
    @app_commands.describe(channel="forum channel to post to (only needed once, to set it)")
    async def archive(interaction: discord.Interaction, channel: discord.ForumChannel = None):
        if interaction.user.id not in ALLOWED_USERS:
            await interaction.response.send_message("you are not allowed to use this command", ephemeral=True)
            return

        if channel:
            config = load_json(CONFIG_FILE, {})
            config["channel_id"] = channel.id
            save_json(CONFIG_FILE, config)
            await interaction.response.send_message(f"archive channel set to {channel.mention}, run /archive again (without the channel option) to start a post", ephemeral=True)
            return

        target_channel = await get_channel(bot)
        if target_channel is None:
            await interaction.response.send_message("no archive channel set yet, run /archive channel:<forum channel> once to set it", ephemeral=True)
            return

        await interaction.response.send_message("starting archive post below", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel.id == interaction.channel.id

        try:
            title = await ask_optional(interaction, bot, check, "add a title")
            if not title:
                await interaction.channel.send("a title is required, cancelled")
                return
            cover_list = await ask_media_optional(interaction, bot, check, "add a cover image", MEDIA_DIR)
            cover = cover_list[0] if cover_list else None
            version = await ask_optional(interaction, bot, check, "java or bedrock?")
            tags = await ask_tags(interaction, bot, check)
            description = await ask_optional(interaction, bot, check, "add a description")
            credits = await ask_list_optional(interaction, bot, check, "add credits")
            features = await ask_list_optional(interaction, bot, check, "add features")
            downsides = await ask_list_optional(interaction, bot, check, "add downsides")
            notes = await ask_optional(interaction, bot, check, "add notes")
            gallery = await ask_media_optional(interaction, bot, check, "add gallery images", MEDIA_DIR)
            downloads = await ask_downloads_optional(interaction, bot, check, "add download files")
        except TimeoutError:
            await interaction.channel.send("archive post timed out, cancelled")
            return

        data = {
            "title": title, "cover": cover, "version": version, "tags": tags,
            "description": description, "credits": credits, "features": features,
            "downsides": downsides, "notes": notes, "gallery": gallery, "downloads": downloads,
        }

        slug = slugify(title)
        md_filename = f"{slug}.md"

        os.makedirs(LISTING_DIR, exist_ok=True)
        with open(os.path.join(LISTING_DIR, md_filename), "w", encoding="utf-8") as f:
            f.write(build_md(data))

        save_json(os.path.join(DATA_DIR, f"{slug}.json"), data)

        manifest = load_json(MANIFEST_FILE, [])
        if md_filename not in manifest:
            manifest.append(md_filename)
        save_json(MANIFEST_FILE, manifest)

        forum_tags = resolve_forum_tags(target_channel, data.get("tags"))
        thread = await upsert_forum_post(bot, target_channel, md_filename, data["title"], build_discord_message(data), build_files(data), applied_tags=forum_tags)
        await interaction.channel.send(f"archive post created: {thread.jump_url}")

    @bot.tree.command(name="archive-edit", description="edit or delete an existing archive post")
    async def archive_edit(interaction: discord.Interaction):
        if interaction.user.id not in ALLOWED_USERS:
            await interaction.response.send_message("you are not allowed to use this command", ephemeral=True)
            return

        manifest = load_json(MANIFEST_FILE, [])
        if not manifest:
            await interaction.response.send_message("no archive posts exist yet", ephemeral=True)
            return

        await interaction.response.send_message("starting edit below", ephemeral=True)

        def check(m):
            return m.author.id == interaction.user.id and m.channel.id == interaction.channel.id

        listing = "\n".join(f"{i+1}. {m}" for i, m in enumerate(manifest))
        await interaction.channel.send(f"which post do you want to edit? reply with the number\n{listing}")
        msg = await bot.wait_for("message", check=check, timeout=600)
        try:
            md_filename = manifest[int(msg.content.strip()) - 1]
        except (ValueError, IndexError):
            await interaction.channel.send("invalid selection, cancelled")
            return

        slug = md_filename[:-3]
        md_path = os.path.join(LISTING_DIR, md_filename)
        data = load_json(os.path.join(DATA_DIR, f"{slug}.json"), None)
        if data is None:
            if not os.path.exists(md_path):
                await interaction.channel.send("post file is missing, cancelled")
                return
            data = parse_md(md_path)

        await interaction.channel.send("edit which field, or type delete to remove this whole post?\n" + ", ".join(FIELDS) + ", delete")
        field_msg = await bot.wait_for("message", check=check, timeout=600)
        field = field_msg.content.strip().lower()

        if field == "delete":
            await interaction.channel.send("type confirm to permanently delete this post")
            confirm_msg = await bot.wait_for("message", check=check, timeout=600)
            if confirm_msg.content.strip().lower() != "confirm":
                await interaction.channel.send("cancelled")
                return

            if os.path.exists(md_path):
                os.remove(md_path)
            json_path = os.path.join(DATA_DIR, f"{slug}.json")
            if os.path.exists(json_path):
                os.remove(json_path)

            manifest.remove(md_filename)
            save_json(MANIFEST_FILE, manifest)

            threads = load_json(THREADS_FILE, {})
            entry = threads.pop(md_filename, None)
            save_json(THREADS_FILE, threads)
            if entry:
                try:
                    thread = bot.get_channel(entry["thread_id"]) or await bot.fetch_channel(entry["thread_id"])
                    await thread.delete()
                except (discord.NotFound, discord.Forbidden):
                    pass

            await interaction.channel.send("post deleted")
            return

        if field not in FIELDS:
            await interaction.channel.send("unknown field, cancelled")
            return

        if field in ("credits", "features", "downsides"):
            data[field] = await edit_list_field(interaction, bot, check, data.get(field) or [], field)
        elif field == "gallery":
            data[field] = await edit_media_field(interaction, bot, check, data.get(field) or [], MEDIA_DIR, "gallery image")
        elif field == "cover":
            new_cover = await ask_media_optional(interaction, bot, check, "enter new cover image", MEDIA_DIR)
            data[field] = new_cover[0] if new_cover else None
        elif field == "downloads":
            data[field] = await edit_downloads_field(interaction, bot, check, data.get(field) or [])
        elif field == "tags":
            data[field] = await ask_tags(interaction, bot, check)
        else:
            data[field] = await ask_optional(interaction, bot, check, f"enter new {field}")

        save_json(os.path.join(DATA_DIR, f"{slug}.json"), data)
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(build_md(data))

        target_channel = await get_channel(bot)
        if target_channel:
            forum_tags = resolve_forum_tags(target_channel, data.get("tags"))
            thread = await upsert_forum_post(bot, target_channel, md_filename, data["title"], build_discord_message(data), build_files(data), applied_tags=forum_tags)
            await interaction.channel.send(f"post updated: {thread.jump_url}")
        else:
            await interaction.channel.send("post updated locally, no archive channel set to post to")