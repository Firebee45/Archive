import discord, re, os, io, json, asyncio, urllib.request
import terminal_reports as log

META = {"name": "archive-link-listener"}

ARCHIVE_LINK_RE = re.compile(r"https?://[^\s]+build\.html\?id=[^\s&]+", re.IGNORECASE)

RENDER_SCRIPT = os.getenv(
    "ARCHIVE_RENDER_SCRIPT",
    os.path.join(os.path.dirname(os.path.dirname(__file__)), "render-card.mjs")
)


async def render_card(url):
    proc = await asyncio.create_subprocess_exec(
        "node", RENDER_SCRIPT, url, "-",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0 or not stdout:
        raise RuntimeError(stderr.decode(errors="ignore") or "render-card.mjs produced no output")

    header, _, png_bytes = stdout.partition(b"\n")
    meta = json.loads(header.decode())
    return meta, png_bytes


def _fetch_bytes(url):
    with urllib.request.urlopen(url, timeout=30) as r:
        return r.read()


async def fetch_download(name, url):
    loop = asyncio.get_event_loop()
    data = await loop.run_in_executor(None, _fetch_bytes, url)
    return discord.File(io.BytesIO(data), filename=name)


def setup(bot):
    @bot.listen("on_message")
    async def archive_link_listener(message: discord.Message):
        if message.author.bot:
            return

        match = ARCHIVE_LINK_RE.search(message.content)
        if not match:
            return

        url = match.group(0)
        log.info("archive-link", f"link detected: {url}")

        async with message.channel.typing():
            try:
                meta, png_bytes = await render_card(url)
            except Exception as e:
                log.error("archive-link", f"render failed for {url}: {e}")
                return

            files = [discord.File(io.BytesIO(png_bytes), filename="archive-card.png")]

            for d in meta.get("downloads", []):
                try:
                    files.append(await fetch_download(d["name"], d["url"]))
                except Exception as e:
                    log.error("archive-link", f"download failed ({d.get('name')}): {e}")

        try:
            await message.reply(files=files, mention_author=False)
        except discord.HTTPException as e:
            log.error("archive-link", f"discord rejected the reply (likely file size limit): {e}")
            return

        log.success("archive-link", f"replied with {len(files)} file(s) for {meta.get('title', url)}")
