import discord
import json
import os
import io
from PIL import Image

import terminal_reports as log
import text_templates as text
import image_utils

META = {"name": "welcome_milestones"}

WELCOME_CHANNEL_ID = 1525473555989401760
MILESTONE_CHANNEL_ID = 1433114243171094688

_DIR = os.path.dirname(__file__)
_TEXT_PATH = os.path.join(_DIR, "welcome_text.json")
_STATE_PATH = os.path.join(_DIR, "milestone_state.json")


def _load_last_milestone():
    if not os.path.exists(_STATE_PATH):
        return 0
    try:
        with open(_STATE_PATH, "r") as f:
            return json.load(f).get("last_milestone", 0)
    except (json.JSONDecodeError, OSError):
        return 0


def _save_last_milestone(value):
    with open(_STATE_PATH, "w") as f:
        json.dump({"last_milestone": value}, f)


def _next_milestone_target(count):
    """
    Returns the highest milestone `count` has reached, or None if it
    hasn't reached a new one yet. Milestones go 100, 200, ... 900,
    then 1000, 1500, 2000, ... every 500 after that.
    """
    if count < 100:
        return None
    if count < 1000:
        return (count // 100) * 100
    return (count // 500) * 500


def _average_color(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
    img = img.resize((32, 32))
    r_total = g_total = b_total = a_total = 0
    for r, g, b, a in img.getdata():
        r_total += r * a
        g_total += g * a
        b_total += b * a
        a_total += a
    if a_total == 0:
        return discord.Color.default()
    return discord.Color.from_rgb(
        round(r_total / a_total),
        round(g_total / a_total),
        round(b_total / a_total),
    )


def setup(bot):
    @bot.event
    async def on_member_join(member: discord.Member):
        strings = text.load(_TEXT_PATH)

        channel = member.guild.get_channel(WELCOME_CHANNEL_ID)
        if channel is None:
            log.warn("welcome_milestones", f"welcome channel {WELCOME_CHANNEL_ID} not found")
        else:
            placeholders = {
                "member": member.mention,
                "server name": member.guild.name,
                "member count": member.guild.member_count,
            }
            welcome_text = text.render_all(strings["welcome"], placeholders)

            avatar_buffer = await image_utils.make_circle_avatar(member)
            embed_color = _average_color(avatar_buffer.getvalue())
            avatar_buffer.seek(0)
            avatar_file = discord.File(avatar_buffer, filename="avatar.png")

            embed = discord.Embed(
                title=welcome_text["title"],
                description=welcome_text["body"],
                color=embed_color,
            )
            embed.set_thumbnail(url="attachment://avatar.png")
            embed.set_footer(text=welcome_text["footer"])

            try:
                await channel.send(embed=embed, file=avatar_file)
                log.success("welcome_milestones", f"sent welcome embed for {member} in #{channel.name}")
            except discord.HTTPException as e:
                log.error("welcome_milestones", f"failed to send welcome embed: {e}")

        # Milestone check
        count = member.guild.member_count
        target = _next_milestone_target(count)
        last = _load_last_milestone()

        if target is not None and target > last:
            milestone_channel = member.guild.get_channel(MILESTONE_CHANNEL_ID)
            if milestone_channel is None:
                log.warn("welcome_milestones", f"milestone channel {MILESTONE_CHANNEL_ID} not found")
                return

            milestone_text = text.render(strings["milestone"]["body"], {"member count": target})

            try:
                await milestone_channel.send(milestone_text)
                _save_last_milestone(target)
                log.success("welcome_milestones", f"announced milestone {target}")
            except discord.HTTPException as e:
                log.error("welcome_milestones", f"failed to send milestone message: {e}")