import io

from PIL import Image, ImageDraw


async def make_circle_avatar(user_or_member, size=256):
    """
    Downloads a user's/member's avatar, crops it to a centered square,
    then masks it into a circle so the corners are transparent.
    Returns a BytesIO of PNG bytes, ready to wrap in discord.File.
    """
    avatar_bytes = await user_or_member.display_avatar.read()

    image = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")

    # Crop to the largest centered square (avatars are already square,
    # but this keeps it safe if a weird source image ever isn't).
    side = min(image.size)
    left = (image.width - side) // 2
    top = (image.height - side) // 2
    image = image.crop((left, top, left + side, top + side))
    image = image.resize((size, size), Image.LANCZOS)

    # Build a circular alpha mask the same size as the image.
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0, size, size), fill=255)

    image.putalpha(mask)

    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer
