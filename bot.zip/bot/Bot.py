import discord
from discord.ext import commands
import os, importlib
from dotenv import load_dotenv
from terminal_reports import error, info, success

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

_modules_loaded = False

def load_modules():
    modules_path = os.path.join(os.path.dirname(__file__), "modules")
    for f in os.listdir(modules_path):
        if not f.endswith(".py"):
            continue
        module_name = f"modules.{f[:-3]}"
        try:
            mod = importlib.import_module(module_name)
            mod.setup(bot)
            success("bot", f"loaded module={module_name}")
        except Exception as exc:
            error("bot", f"failed module={module_name} error={exc!r}")
            raise

GUILD_ID = discord.Object(id=1411133575650213905)

@bot.event
async def on_ready():
    global _modules_loaded
    if not _modules_loaded:
        info("bot", "loading command modules")
        load_modules()
        _modules_loaded = True
    bot.tree.copy_global_to(guild=GUILD_ID)
    await bot.tree.sync(guild=GUILD_ID)
    success("bot", f"logged in user={bot.user} guild={GUILD_ID.id}")

bot.run(os.getenv("TOKEN"))