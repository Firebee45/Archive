#!/usr/bin/env node
import puppeteer from 'puppeteer';

const RAW='https://raw.githubusercontent.com/Firebee45/Archive/main/Archive';
const CSS=['assets/css/variables.css','assets/css/base.css','assets/css/components/archive-build.css','assets/css/components/archive-tags.css'];

const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const slug=s=>s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');

function parseTags(raw){const c={};raw.split('\n').forEach(l=>{const m=l.match(/^-\s*([^:]+):\s*(.+)$/);if(m)c[m[1].trim()]=m[2].trim();});return c;}

async function ft(p){const r=await fetch(`${RAW}/${p}`);if(!r.ok)throw new Error(p);return r.text();}
async function fto(p){try{return await ft(p);}catch{return null;}}

function build(item,tags){
  const t=(item.tags||[]).map(tag=>{const h=tags[tag];const s=h?`style="background-color:${h}8c;border-color:${h}aa;color:#fff;"`:'';return `<span class="Archive-tag" ${s}>${esc(tag)}</span>`;}).join('');
  return `<div class="Archive-build"><div class="Archive-build-media"><img src="${item.imageUrl||''}" class="Archive-build-image" alt="${esc(item.title)}" crossorigin="anonymous"></div><div class="Archive-build-panel"><div class="Archive-build-tags">${t}</div><h1 class="Archive-build-title">${esc(item.title)}</h1><div class="Archive-build-description"><p>${esc(item.description)}</p></div></div></div>`;
}

async function main(){
  const [,,inputArg,outputArg]=process.argv;
  if(!inputArg){console.error('Usage: node render-card.mjs <url> [out.png]');process.exit(1);}
  const id=new URL(inputArg).searchParams.get('id');
  if(!id){console.error('No ?id= param in URL');process.exit(1);}
  const filename=`${id}.md`;

  const browserP=puppeteer.launch();

  const [buildMdSrc,raw,tagsRaw,...cssTexts]=await Promise.all([
    ft('assets/js/build-markdown.js'),
    ft(`listing-data/${filename}`),
    fto('listing-data/tag-colours.md'),
    ...CSS.map(ft)
  ]);

  const mod=await import(`data:text/javascript,${encodeURIComponent(buildMdSrc)}`);
  const parsed=mod.parseBuildMarkdown(raw);
  const item={...parsed,description:mod.toPlainText(parsed.description)};
  if(item.image)item.imageUrl=`${RAW}/${item.image}`;
  const tagColors=tagsRaw?parseTags(tagsRaw):{};

  const html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700&family=DM+Mono:wght@300;400;500&display=swap" rel="stylesheet"><style>${cssTexts.join('')}html,body{margin:0;padding:0;background:${'#0b0a08'}}.build-wrap{width:900px;padding:2rem}.Archive-build{margin:0}</style></head><body><div class="build-wrap">${build(item,tagColors)}</div></body></html>`;

  const browser=await browserP;
  const page=await browser.newPage();
  await page.setViewport({width:1000,height:600,deviceScaleFactor:2});
  await page.setContent(html,{waitUntil:'networkidle0'});
  await page.evaluate(()=>document.fonts.ready);
  const el=await page.$('.Archive-build');

  if(outputArg==='-'){
    const buf=await el.screenshot();
    await browser.close();
    const downloads=(item.downloads||[]).map(d=>({name:d.name,url:`${RAW}/${encodeURI(d.path)}`}));
    const meta=JSON.stringify({title:item.title,downloads});
    process.stdout.write(meta+'\n');
    process.stdout.write(buf);
    return;
  }

  const out=outputArg||`card-${slug(item.title)}.png`;
  await el.screenshot({path:out});
  await browser.close();
  console.log(out);
}
main().catch(e=>{console.error(e);process.exit(1);});
